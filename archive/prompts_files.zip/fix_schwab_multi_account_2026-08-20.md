# Build Prompt: `fetch_positions()` Multi-Account Aggregation

**Author:** Claude (Chief Architect), 2026-08-20
**Executor:** Claude Code or Gemini CLI
**Prompt version:** 1.0.0
**Type:** Correctness bug fix. Not a feature.

**Why this ranks above the store migration:** this is wrong data, not awkward data. Every downstream figure — position weights, style ceiling breach flags, look-through exposure, Crosshairs ranking — divides by a total market value derived from `fetch_positions()`. If the account set is wrong, the ceilings are wrong, and pre-committed criteria stop binding correctly.

---

## Sequencing constraint — read first

This fix changes the position and possibly transaction set. That interacts with the store migration:

- **Do this BEFORE Phase 1 dual-write begins**, or **after Phase 2 cutover is complete**.
- **Do NOT do this during the Phase 1 streak window.** A changing transaction set mid-streak invalidates the Sheets↔SQLite reconcile and produces a FAIL that looks like a store bug but is not.

If Phase 1 dual-write is already running, STOP and report rather than proceeding.

---

## Scope boundary

**In scope:** account discovery, account selection, and position/transaction attribution in `utils/schwab_client.py` and its callers.

**Out of scope:** anything in `core/store/`, the bundle schema, agents, or Sheets layout. If the fix appears to require a schema change, STOP and report.

---

## Critical domain constraint

**Not all five Schwab accounts belong in this system.** Per project instructions:

> This is not the reserve account. Schwab ...8895 (~$12.5K) is tracked in the RE Property Manager's `Reserve_Ledger` and is out of scope here.

The correct fix is therefore **NOT** "aggregate all accounts." It is an **explicit allowlist** of accounts this repo owns, with everything else excluded by default. Blind aggregation would silently pull the reserve account — and any other account — into portfolio scale, weights and ceilings, converting an under-count bug into an over-count bug.

Default posture: **deny unless listed.**

---

## Step 0 — Verification gate (paste RAW stdout under each)

Unedited terminal output only. No summaries.

- [ ] **Locate the function and its account handling**

```text
rg -n "def fetch_positions|accountNumber|hashValue|securitiesAccount|accounts" utils/schwab_client.py
```

- [ ] **Identify every caller**

```text
rg -n "fetch_positions" --glob "*.py" -g "!archive/**"
```

- [ ] **Confirm what the API actually returns (read-only call, no writes)**

```text
python -c "from utils.schwab_client import <account-listing-fn>; import json; r=<account-listing-fn>(); print(json.dumps(r, indent=2)[:4000])"
# Substitute the real account-listing function found in the first grep.
# Expected: five account entries. Paste raw. REDACT full account numbers to last 4 before pasting.
```

- [ ] **Existing account config, if any**

```text
rg -n "ACCOUNT|SCHWAB_ACCOUNT" config.py .env.example
```

- [ ] **Confirm no order/trading endpoint is reachable from this module**

```text
rg -n "order|Order|place|execute|trade_execute" utils/schwab_client.py
# Expected: no order-placement endpoints. Any hit is a STOP condition.
```

If any box fails or the account listing does not return five entries, **STOP** and report.

---

## Diagnosis before fix

Determine which of these is true. Do not fix before naming the cause:

| Hypothesis | Signature |
|---|---|
| Single-account API call | Function requests one account hash, never iterates |
| Loop with early return | Iterates but `return`s inside the loop instead of accumulating |
| Silent exception per account | Try/except swallows failures for four accounts |
| Response shape assumption | Parses `[0]` of a list rather than mapping all entries |
| Token scope | Token authorises one account only |

State the confirmed cause with the line number and the evidence before writing the fix.

---

## Required behaviour after fix

1. `config.SCHWAB_ACCOUNT_ALLOWLIST` — explicit list of account identifiers (last 4 or hash) this repo owns. **Reserve account ...8895 must not appear in it.**
2. `fetch_positions()` iterates the allowlist and accumulates. It never returns inside the loop.
3. Each returned position carries its source account identifier.
4. **Fail loud, not quiet.** If an allowlisted account returns no data or errors, raise or emit a health-check failure. A silently short position set is the bug being fixed and must not be reachable.
5. If the API returns an account not in the allowlist, log it at INFO and exclude it. Do not error — new accounts are Bill's business, not the code's.
6. If the allowlist is empty or unset, **fail closed** with a clear message. Do not fall back to "all accounts."

---

## Impact disclosure (required deliverable)

Before/after comparison written to `agent_outputs/schwab_account_fix/impact_YYYY-MM-DD.md`:

| Metric | Before | After | Delta |
|---|---|---|---|
| Accounts loaded | | | |
| Position count | | | |
| Total market value | | | |
| Positions newly appearing | list | | |
| Style ceiling breaches gained/lost | | | |

**If total market value or position count changes materially, that is a reportable finding, not a silent success.** `CLAUDE.md` currently records ~$596K / 35 positions as verified scale. If the corrected figure differs, `CLAUDE.md` and `state.md` both need updating and the delta must be surfaced explicitly — Bill needs to know whether four accounts of holdings were invisible or whether the count was right all along and only one account was ever in scope.

---

## Post-build verification checklist (raw stdout required)

- [ ] `python -c "import config; print(config.SCHWAB_ACCOUNT_ALLOWLIST)"` — reserve account absent
- [ ] `python manager.py sync positions` (dry-run) — prints per-account counts, one line per allowlisted account
- [ ] Simulate one allowlisted account failing — health check flags it; does NOT return a partial set silently
- [ ] Empty allowlist — fails closed with a readable message
- [ ] `python manager.py morning` (dry-run) end to end — no traceback
- [ ] Impact file exists and is populated with real numbers
- [ ] `git diff --stat` — no changes under `core/store/`, `core/bundle.py`, or `utils/agents/`
- [ ] `rg -n "order|place_order" utils/schwab_client.py` — still no trading endpoints
