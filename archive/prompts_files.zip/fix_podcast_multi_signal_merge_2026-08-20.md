# Build Prompt: Podcast Multi-Signal Merge (stop last-write-wins)

**Author:** Claude (Chief Architect), 2026-08-20
**Executor:** Claude Code or Gemini CLI
**Prompt version:** 1.0.0
**Type:** Data-loss fix. Top backlog item.

**Problem:** ten channels write to `AI_Suggested_Allocation` in a single morning run. Last write wins, so nine channels' signal is discarded every run. Transcripts survive on disk; the extracted allocation signal does not.

**Design posture:** fire-fire-aim. Ship the minimum that stops the data loss and makes disagreement visible. **Do NOT build a weighted consensus scoring rubric, a source-credibility model, or a confidence metric in v1.** Bill has not seen real merged output yet; scoring it before he has is exactly the over-spec the project philosophy forbids.

---

## Sequencing

Independent of the store migration. `AI_Suggested_Allocation` is a sandbox tab and is explicitly excluded from the ledger ("do not dual-write agent sandbox tabs into the ledger as truth"). Safe to run in parallel with Phase 1.

---

## Scope boundary

**In scope:** `tasks/batch_podcast_sync.py`, `utils/agents/podcast_analyst.py`, and the write path to `AI_Suggested_Allocation`.

**Out of scope:** transcript fetching, the Spotify aggregate ingestion path (manual by standing decision, 2026-07-26), per-channel title filtering, and anything under `core/`.

The Spotify aggregate is a **single first-class source in its own voice** and must not be decomposed into constituent episodes by this or any other change. If merge logic would treat it as N sources, that is a bug.

---

## Step 0 — Verification gate (paste RAW stdout under each)

- [ ] **Locate the write and confirm the overwrite**

```text
rg -n "AI_Suggested_Allocation|TAB_AI_SUGGESTED|clear\(\)|update\(" tasks/batch_podcast_sync.py utils/sheet_writers.py
```

- [ ] **Confirm the loop structure — where per-channel results are lost**

```text
rg -n "for .*channel|analyze_podcast|SectorTarget|PodcastStrategy" tasks/batch_podcast_sync.py utils/agents/podcast_analyst.py
```

- [ ] **Confirm channel config and count**

```text
rg -n "channels|CHANNEL|rss" config.py data/*.json | head -50
```

- [ ] **Confirm the aggregate branch exists and is distinct**

```text
rg -n "is_stax|aggregate|PROVENANCE" utils/agents/podcast_analyst.py tasks/batch_podcast_sync.py
```

- [ ] **Current tab contents (evidence of the loss)**

```text
python manager.py refresh podcasts --dry-run
# Paste raw. Expect to see N channels processed but one surviving write.
```

If the overwrite cannot be demonstrated, **STOP** — the diagnosis is wrong and the fix would be speculative.

---

## Required behaviour after fix

### 1. Accumulate, then write once

Per-channel results collect into an in-memory list across the whole run. One single-batch write at the end. No per-channel write to the tab.

### 2. Every row carries provenance

Each allocation row must be attributable:

| Column | Content |
|---|---|
| `source` | Channel name or aggregate name |
| `source_type` | `episode` or `aggregate` |
| `episode_date` | Publish date |
| `sector` / `ticker` | As extracted |
| `direction` | As extracted (no numeric target invention) |
| `run_date` | Pipeline run date |

### 3. Disagreement is preserved, not resolved

If two channels point opposite directions on the same sector, **both rows survive**. Do not average, net, or suppress. Contradiction between sources is signal — it is the thing Bill would want to see and the thing last-write-wins currently destroys.

### 4. A plain agreement count, nothing more

One derived block: for each sector/ticker, how many distinct sources mentioned it and in which direction. A count. No weighting, no score, no ranking.

**Double-count guard:** if the Spotify aggregate cites an episode that was also independently ingested in the same window, the aggregate and the episode are **one source each**, not two agreeing sources. Use the aggregate's `## Cited Episodes` cross-reference to detect the overlap and mark the row rather than counting it twice. This is the known corpus risk on record — reproducing it is a FAIL.

### 5. Archive before overwrite

Existing tab contents archive to `Agent_Outputs_Archive` before the batch write, per hard rule 7.

---

## Explicit non-goals for v1

- No credibility weighting by channel
- No confidence scores
- No consensus threshold that suppresses minority views
- No writes to `Target_Allocation` — ever
- No numeric allocation percentages the sources did not state

---

## Post-build verification checklist (raw stdout required)

- [ ] `python manager.py refresh podcasts --dry-run` — prints all N channels accumulated, one batch write planned
- [ ] `--live` once — tab contains rows from **all** channels that produced signal; count matches dry-run
- [ ] Manufacture two channels disagreeing on one sector — both rows present after the run
- [ ] Aggregate + a cited episode both in window — agreement count shows the overlap flagged, not double-counted
- [ ] `Agent_Outputs_Archive` received the prior contents before overwrite
- [ ] `rg -n "Target_Allocation" tasks/batch_podcast_sync.py` — no matches
- [ ] Spotify aggregate still ingested as one source in its own voice — not decomposed
- [ ] `git diff --stat` — no changes under `core/`
